import { Component, OnInit } from '@angular/core';
import { UserDashboardService } from 'src/app/service/user-dashboard-service.service';

@Component({
  selector: 'upcoming-installments',
  templateUrl: './upcoming-installments.component.html',
  styleUrls: ['./upcoming-installments.component.css']
})
export class UpcomingInstallmentsComponent implements OnInit {

  upcoming: any;
  flag: boolean = false;
  buttonFlag: boolean = true;

  constructor(private userService: UserDashboardService) { }

  ngOnInit(): void {
    this.getUpcomingTransactions();
  }

  getUpcomingTransactions() {
    this.userService.getUpcomingTransactions(103).subscribe(
      data => {
        this.upcoming = data;
      }
    );
  }

  displayAll() {
    this.flag = true;
    this.buttonFlag = false;
  }
}
