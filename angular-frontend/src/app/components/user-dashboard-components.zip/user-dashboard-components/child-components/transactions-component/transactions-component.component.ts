import { Component, OnInit } from '@angular/core';
import { Transactions } from 'src/app/models/Transactions';
import { UserDashboardService } from 'src/app/service/user-dashboard-service.service';

@Component({
  selector: 'transactions-component',
  templateUrl: './transactions-component.component.html',
  styleUrls: ['./transactions-component.component.css']
})
export class TransactionsComponent implements OnInit {
  transactions: any;
  constructor(private userService: UserDashboardService) { }

  ngOnInit(): void {
    this.getTransactionDetails();
  }

  getTransactionDetails() {
    this.userService.getTransactionDetails(103).subscribe(
      data => {
        this.transactions = data;
      }
    );
  }

}
