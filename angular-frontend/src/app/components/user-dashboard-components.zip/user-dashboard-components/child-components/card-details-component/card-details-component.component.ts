import { Component, OnInit } from '@angular/core';
import { Cards } from 'src/app/models/Cards';
import { UserDashboardService } from 'src/app/service/user-dashboard-service.service';

@Component({
  selector: 'card-details-component',
  templateUrl: './card-details-component.component.html',
  styleUrls: ['./card-details-component.component.css']
})
export class CardDetailsComponent implements OnInit {

  cardData: any;
  cardDetails: Cards;
  balanceCredit: number;

  constructor(private userService: UserDashboardService) { 

  }

  ngOnInit(): void {
    this.getCardDetails();
    console.log(this.cardDetails);
  }

    getCardDetails() {
      this.userService.getCardDetails(103).subscribe(
      data => {
        this.cardData = data;
        this.cardDetails = new Cards(this.cardData.card_id, this.cardData.card_no, this.cardData.card_type, this.cardData.expiry_date, this.cardData.limit, this.cardData.status, this.cardData.issue_date, this.cardData.joining_fee, this.cardData.user_id);
      }
    );

    this.userService.getBalanceCredit(103).subscribe(
      data => {
        this.balanceCredit = data;
      }
    );
  }

}
