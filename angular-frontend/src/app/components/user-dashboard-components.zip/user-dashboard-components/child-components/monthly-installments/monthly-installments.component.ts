import { Component, OnInit } from '@angular/core';
import { MonthlyPaidTransactions } from 'src/app/models/MonthlyPaidTransactions';
import { UserDashboardService } from 'src/app/service/user-dashboard-service.service';

@Component({
  selector: 'monthly-installments',
  templateUrl: './monthly-installments.component.html',
  styleUrls: ['./monthly-installments.component.css']
})
export class MonthlyInstallmentsComponent implements OnInit {

  monthlyPaid: any;
  flag: boolean = false;
  buttonFlag: boolean = true;

  constructor(private userService: UserDashboardService) { }

  ngOnInit(): void {
    this.getMonthlyPaidTransactions();
  }

  getMonthlyPaidTransactions() {
    this.userService.getMonthlyPaidTransactions(103).subscribe(
      data => {
        console.log(data);
        // this.monthlyPaid = new MonthlyPaidTransactions(data.mtxn_id, data.transaction_id, data.product_name, data.amount, data.mtxn_date, data.m_status);
        this.monthlyPaid = data;
      }
    );
  }

  displayAll() {
    this.flag = true;
    this.buttonFlag = false;
  }

}
