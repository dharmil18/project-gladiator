import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/service/login-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm : FormGroup;
  users: any = [];
  loginMessage: any;

  constructor(private fb:FormBuilder, private loginService: LoginService, private router: Router) {
    this.loginForm = this.fb.group({
      "user_name": [null,Validators.required],
      "password": [null,Validators.required]
    })
    this.users = this.loginForm.value;
    // console.log(this.loginForm.value);
   }

  ngOnInit(): void {
    console.log(this.loginMessage);
  }

  formValues() {
    const user_name: string = this.loginForm.controls["user_name"].value;
    const password: string = this.loginForm.controls["password"].value;
    this.loginService.login(user_name, password).subscribe(
      (data) => {
        this.loginMessage = data;
        console.log(this.loginMessage.status);
        console.log(this.loginMessage.message);
        console.log(this.loginMessage.statusCode);
        console.log(this.loginMessage.loginUserData);

        if(this.loginMessage.status == 'Success')
          this.router.navigate(['/user-dashboard']);
        else
          alert("Invalid Username or Password");
      },
      error => {
        console.log(error);
      }
    );
  }

}



